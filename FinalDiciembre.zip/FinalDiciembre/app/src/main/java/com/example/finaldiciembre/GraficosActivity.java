package com.example.finaldiciembre;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class GraficosActivity extends AppCompatActivity {
    private SimpleLineGraph graph1;
    private SimpleLineGraph graph2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graficos); // Diseño para mostrar los gráficos

        // Inicializar los gráficos
        graph1 = findViewById(R.id.graph1);
        graph2 = findViewById(R.id.graph2);

        // Obtener los datos pasados desde ResultadosActivity
        Intent intent = getIntent();
        ArrayList<Float> vector1 = (ArrayList<Float>) intent.getSerializableExtra("VECTOR1");
        ArrayList<Float> vector2 = (ArrayList<Float>) intent.getSerializableExtra("VECTOR2");

        // Verificar si los vectores no son nulos y no están vacíos
        if (vector1 != null && !vector1.isEmpty()) {
            graph1.setData(vector1);  // Asignar datos al gráfico 1
        } else {
            Toast.makeText(this, "Datos del gráfico 1 no disponibles", Toast.LENGTH_SHORT).show();
        }

        if (vector2 != null && !vector2.isEmpty()) {
            graph2.setData(vector2);  // Asignar datos al gráfico 2
        } else {
            Toast.makeText(this, "Datos del gráfico 2 no disponibles", Toast.LENGTH_SHORT).show();
        }
    }
}