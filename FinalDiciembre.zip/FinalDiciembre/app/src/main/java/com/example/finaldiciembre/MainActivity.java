package com.example.finaldiciembre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onCOMENZAR(View view) {
        Intent j = new Intent(MainActivity.this, Ventana2.class);
        startActivity(j);

    }
    public void inABOUT(View view) {
        Intent i = new Intent(MainActivity.this, MainActivity2.class);
        startActivity(i);

    }
}

