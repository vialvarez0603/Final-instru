package com.example.finaldiciembre;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Resultados extends AppCompatActivity {
    private Button buttonVerGraficos; // Botón para ver los gráficos
    private static final int PERMISSION_REQUEST_CODE = 1;
    private ArrayList<Float> vector1 = new ArrayList<>();
    private ArrayList<Float> vector2 = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultados);

        // Inicialización de la UI
        buttonVerGraficos = findViewById(R.id.buttonVerGraficos); // Este es el botón para ver los gráficos
        final TextView textViewResultado = findViewById(R.id.textViewResultado);
        final TextView textViewFrecuencia = findViewById(R.id.textViewFrecuencia);
        final TextView textViewTiempo = findViewById(R.id.textViewTiempo);
        final TextView textViewEpisodios = findViewById(R.id.textViewEpisodios);

        // Obtener los datos de la actividad anterior
        Intent intent = getIntent();
        String diagnosticoBruxismo = intent.getStringExtra("DIAGNOSTICO");
        float frecuenciaEpisodios = intent.getFloatExtra("FRECUENCIA", 0.0f);
        String tiempoStr = intent.getStringExtra("DURACION");
        int episodios = intent.getIntExtra("EPISODIOS", 0);
        ArrayList<ArrayList<Float>> emgEpisodes = (ArrayList<ArrayList<Float>>) intent.getSerializableExtra("EPISODES_DATA");
        Log.d("Resultados", "Vector " + emgEpisodes);
        // Dividir emgEpisodes en dos vectores



        if (emgEpisodes != null && !emgEpisodes.isEmpty()) {
            ArrayList<Float> combinedData = new ArrayList<>();
            combinedData.addAll(emgEpisodes.get(0));  // Agregar los elementos del primer ArrayList
            combinedData.addAll(emgEpisodes.get(1));   // Tomamos la primera lista

            int firstNaNIndex = -1;
            int secondNaNIndex = -1;

            // Encontrar las posiciones del primer y segundo NaN
            for (int i = 0; i < combinedData.size(); i++) {
                if (Float.isNaN(combinedData.get(i))) {
                    if (firstNaNIndex == -1) {
                        firstNaNIndex = i;  // Primer NaN encontrado
                    } else {
                        secondNaNIndex = i;  // Segundo NaN encontrado
                        break;  // Ya no necesitamos seguir buscando
                    }
                }
            }

            // Limpiar los vectores antes de llenarlos
            vector1.clear();
            vector2.clear();

            // Llenar vector1 (antes del primer NaN)
            if (firstNaNIndex != -1) {
                for (int i = 0; i < firstNaNIndex; i++) {
                    vector1.add(combinedData.get(i));
                }
            }

            // Llenar vector2 (entre el primer y segundo NaN o hasta el final si solo hay un NaN)
            if (secondNaNIndex != -1) {
                for (int i = firstNaNIndex + 1; i < secondNaNIndex; i++) {
                    vector2.add(combinedData.get(i));
                }
            } else if (firstNaNIndex != -1) {  // Solo un NaN encontrado, copiar hasta el final
                for (int i = firstNaNIndex + 1; i < combinedData.size(); i++) {
                    vector2.add(combinedData.get(i));
                }
            }



            Log.d("Resultados", "Vector 1: " + vector1.toString());
            Log.d("Resultados", "Vector 2: " + vector2.toString());
        }

        // Actualizar la UI con los datos
        textViewResultado.setText(diagnosticoBruxismo);
        textViewFrecuencia.setText(String.format("Frecuencia de episodios:" + frecuenciaEpisodios));
        textViewTiempo.setText(String.format("Duración total: "  + tiempoStr));
        textViewEpisodios.setText(String.format("Episodios detectados: " + episodios));


        // Configurar el evento del botón para ver los gráficos
        buttonVerGraficos.setOnClickListener(view -> {
            // Crear un Intent para ir a GraficosActivity
            Intent intentGraficos = new Intent(Resultados.this, GraficosActivity.class);
            intentGraficos.putExtra("VECTOR1", vector1); // Pasar datos del gráfico 1
            intentGraficos.putExtra("VECTOR2", vector2); // Pasar datos del gráfico 2
            startActivity(intentGraficos); // Iniciar la actividad de gráficos
        });
    }
}