package com.example.finaldiciembre;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Ventana4 extends AppCompatActivity {
    private Button button;
    private CheckBox checkbox;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ventana4);

        button = findViewById(R.id.Button);
        checkbox = findViewById(R.id.checkbox);
        imageView = findViewById(R.id.imageView5);
        // Hacer que el botón sea invisible al inicio
        button.setVisibility(View.INVISIBLE);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Configurar el listener para la CheckBox
        checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                button.setVisibility(View.VISIBLE);
            } else {
                button.setVisibility(View.INVISIBLE);
            }
        });

        // Configurar el listener para el botón
        button.setOnClickListener(view -> {
            Intent intent = new Intent(com.example.finaldiciembre.Ventana4.this, Ventana7.class);
            startActivity(intent);
        });
        imageView.setOnClickListener(view -> {
            Intent intent = new Intent(com.example.finaldiciembre.Ventana4.this, ImageviewActivity.class);
            intent.putExtra("imageResId", R.drawable.electrodos);
            startActivity(intent);
        });
    }
}
