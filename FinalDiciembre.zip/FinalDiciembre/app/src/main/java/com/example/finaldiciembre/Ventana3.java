package com.example.finaldiciembre;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Ventana3 extends AppCompatActivity{

    private String diagnosticoBruxismo;
    private String frecuenciaEpisodios;
    private String TiempoTotal;
    private String Episodios;
    private String usuario;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana3);

        // Obtener los extras del Intent
        Intent intent = getIntent();
        diagnosticoBruxismo = intent.getStringExtra("DIAGNOSTICO_BRUXISMO");
        frecuenciaEpisodios = intent.getStringExtra("FRECUENCIA_EPISODIOS");
        TiempoTotal = intent.getStringExtra("TiempoTotal");
        Episodios = intent.getStringExtra("Episodios");
        usuario = intent.getStringExtra("USUARIO");
        password = intent.getStringExtra("PASSWORD");
    }

    public void inNuevoEst(View view) {
        Intent i = new Intent(this, Ventana4.class);
        startActivity(i);
    }

    public void inCerrarSes(View view){
        // Vuelve a la pantalla de inicio de sesión
        Intent intent = new Intent( Ventana3.this, Ventana2.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

}