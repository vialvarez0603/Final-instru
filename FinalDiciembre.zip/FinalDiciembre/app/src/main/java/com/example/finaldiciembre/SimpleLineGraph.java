package com.example.finaldiciembre;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;

public class SimpleLineGraph extends View {
    private ArrayList<Float> data = new ArrayList<>();
    private Paint linePaint;
    private Paint axisPaint;
    private Paint textPaint;

    public SimpleLineGraph(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        linePaint = new Paint();
        linePaint.setColor(Color.BLUE);
        linePaint.setStrokeWidth(5f);
        linePaint.setStyle(Paint.Style.STROKE);

        axisPaint = new Paint();
        axisPaint.setColor(Color.BLACK);
        axisPaint.setStrokeWidth(3f);

        textPaint = new Paint();
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(30f);
    }

    public void setData(ArrayList<Float> data) {
        this.data = data;
        invalidate(); // Redibuja la vista
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Dibujar los ejes
        int width = getWidth();
        int height = getHeight();
        int padding = 50;

        // Eje X
        canvas.drawLine(padding, height - padding, width - padding, height - padding, axisPaint);
        // Eje Y
        canvas.drawLine(padding, padding, padding, height - padding, axisPaint);

        // Etiquetas de los ejes
        canvas.drawText("Tiempo", width / 2f, height - 10, textPaint); // Etiqueta eje X
        canvas.save();
        canvas.rotate(-90, 10, height / 2f); // Girar texto para eje Y
        canvas.drawText("EMG", 10, height / 2f, textPaint);
        canvas.restore();

        if (data == null || data.isEmpty()) return;

        // Dibujar la línea de datos
        float maxData = getMax(data);
        float xStep = (width - 2 * padding) / (float) data.size();
        float yScale = (height - 2 * padding) / maxData;

        for (int i = 0; i < data.size() - 1; i++) {
            float startX = padding + i * xStep;
            float startY = height - padding - data.get(i) * yScale;
            float stopX = padding + (i + 1) * xStep;
            float stopY = height - padding - data.get(i + 1) * yScale;

            canvas.drawLine(startX, startY, stopX, stopY, linePaint);
        }
    }

    private float getMax(ArrayList<Float> data) {
        float max = Float.MIN_VALUE;
        for (float value : data) {
            if (value > max) {
                max = value;
            }
        }
        return max > 0 ? max : 1; // Evitar divisiones por cero
    }
}